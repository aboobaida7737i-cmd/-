package com.yadalkhair.customer;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;
import android.widget.Toast;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SmsAlarmReceiver extends android.content.BroadcastReceiver {
    private static final String PREF = "scheduled_sms";
    private static final String ACTION = "com.yadalkhair.customer.SEND_SMS";

    @Override public void onReceive(Context context, Intent intent) {
        if (!ACTION.equals(intent.getAction())) return;
        String id = intent.getStringExtra("id");
        String phone = intent.getStringExtra("phone");
        String message = intent.getStringExtra("message");
        if (phone != null && message != null) sendNow(context, phone, message);
        if (id != null) scheduleFromStored(context, id);
    }

    public static void sendNow(Context context, String phone, String message) {
        if (Build.VERSION.SDK_INT >= 23 && context.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(context, "يجب السماح للتطبيق بإرسال SMS حتى يعمل الإرسال التلقائي", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            SmsManager sms = SmsManager.getDefault();
            if (message.length() > 160) {
                sms.sendMultipartTextMessage(phone, null, sms.divideMessage(message), null, null);
            } else sms.sendTextMessage(phone, null, message, null, null);
        } catch (Exception e) {
            Toast.makeText(context, "تعذر إرسال SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public static void schedule(Context context, String id, String phone, String message, int hour, int minute) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(id + ".phone", phone).putString(id + ".message", message)
                .putInt(id + ".hour", hour).putInt(id + ".minute", minute)
                .putBoolean(id + ".enabled", true).apply();
        scheduleAlarm(context, id, phone, message, hour, minute);
    }

    public static void cancel(Context context, String id) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pendingIntent(context, id);
        am.cancel(pi); pi.cancel();
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(id + ".enabled", false).apply();
    }

    public static void scheduleFromStored(Context context, String id) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!p.getBoolean(id + ".enabled", false)) return;
        scheduleAlarm(context, id, p.getString(id + ".phone", ""), p.getString(id + ".message", ""), p.getInt(id + ".hour", 18), p.getInt(id + ".minute", 0));
    }

    public static void rescheduleAll(Context context) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        for (String key : p.getAll().keySet()) {
            if (key.endsWith(".enabled") && p.getBoolean(key, false)) scheduleFromStored(context, key.substring(0, key.length()-8));
        }
    }

    private static void scheduleAlarm(Context context, String id, String phone, String message, int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, minute); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pendingIntent(context, id, phone, message);
        if (Build.VERSION.SDK_INT >= 23) {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
        } else am.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
    }

    private static PendingIntent pendingIntent(Context c, String id) { return pendingIntent(c,id,"",""); }
    private static PendingIntent pendingIntent(Context c, String id, String phone, String message) {
        Intent i = new Intent(c, SmsAlarmReceiver.class).setAction(ACTION).putExtra("id",id).putExtra("phone",phone).putExtra("message",message);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT; if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, id.hashCode(), i, flags);
    }
}
