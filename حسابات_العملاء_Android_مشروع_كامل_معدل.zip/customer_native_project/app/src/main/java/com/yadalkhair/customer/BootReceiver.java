package com.yadalkhair.customer;

public class BootReceiver extends android.content.BroadcastReceiver {
    @Override public void onReceive(android.content.Context context, android.content.Intent intent) {
        SmsAlarmReceiver.rescheduleAll(context);
    }
}
