package com.yadalkhair.customer;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    public static final int CONTACT_REQ = 1001;
    public static final int PICK_PHONE = 1002;
    public static final int SMS_REQ = 1003;
    private WebView webView;
    private String contactCallback = "";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeBridge(this), "Android");
        webView.loadUrl("file:///android_asset/htmlapp/index.html");
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SMS_REQ);
        }
    }

    public void pickContact(String callback) {
        contactCallback = callback == null ? "onContactSelected" : callback;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, CONTACT_REQ);
            return;
        }
        launchPhonePicker();
    }

    private void launchPhonePicker() {
        Intent i = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(i, PICK_PHONE);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_REQ) {
            if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) Toast.makeText(this, "لن يعمل الإرسال التلقائي SMS بدون إذن إرسال الرسائل", Toast.LENGTH_LONG).show();
        }
        if (requestCode == CONTACT_REQ) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchPhonePicker();
            else Toast.makeText(this, "يلزم السماح بالوصول إلى سجل الأسماء لاختيار رقم العميل", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_PHONE || resultCode != Activity.RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        ContentResolver cr = getContentResolver();
        Cursor c = null;
        try {
            c = cr.query(uri, new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);
            if (c != null && c.moveToFirst()) {
                String name = c.getString(0);
                String phone = c.getString(1);
                String js = "window." + contactCallback + "(" + jsString(name) + "," + jsString(phone) + ");";
                webView.post(() -> webView.evaluateJavascript(js, null));
            }
        } finally { if (c != null) c.close(); }
    }

    private static String jsString(String v) {
        if (v == null) v = "";
        return "'" + v.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "\\r") + "'";
    }

    public class NativeBridge {
        private final Context ctx;
        NativeBridge(Context c) { ctx = c; }
        @JavascriptInterface public void pickContact() { MainActivity.this.runOnUiThread(() -> MainActivity.this.pickContact("onContactSelected")); }
        @JavascriptInterface public void sendSms(String phone, String message) {
            SmsAlarmReceiver.sendNow(ctx, phone, message);
        }
        @JavascriptInterface public void scheduleSms(String id, String phone, String message, int hour, int minute) {
            SmsAlarmReceiver.schedule(ctx, id, phone, message, hour, minute);
        }
        @JavascriptInterface public void cancelSms(String id) { SmsAlarmReceiver.cancel(ctx, id); }
        @JavascriptInterface public boolean canScheduleExact() {
            if (Build.VERSION.SDK_INT >= 31) return ((android.app.AlarmManager)getSystemService(ALARM_SERVICE)).canScheduleExactAlarms();
            return true;
        }
        @JavascriptInterface public void openExactAlarmSettings() {
            if (Build.VERSION.SDK_INT >= 31) startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));
        }
    }
}
