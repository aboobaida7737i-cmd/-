const KEY="customer_accounts_v1";
const SETTINGS="customer_settings_v1";
let db=JSON.parse(localStorage.getItem(KEY)||'{"customers":[]}');
let settings=JSON.parse(localStorage.getItem(SETTINGS)||'{"shopName":"","shopPhone":"","shopPhoto":"","lock":false,"pin":"","dark":false,"channel":"sms","schedule":"18:00"}');
let currentCustomer=null, currentPage="home";

const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const money=n=>Number(n||0).toLocaleString("ar-YE",{maximumFractionDigits:2});
function save(){localStorage.setItem(KEY,JSON.stringify(db));localStorage.setItem(SETTINGS,JSON.stringify(settings));}
function toast(t){const x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),2500)}
function openDrawer(){ $("#drawer").classList.add("open"); $("#drawerShade").classList.add("open");}
function closeDrawer(){ $("#drawer").classList.remove("open"); $("#drawerShade").classList.remove("open");}
function modal(title,body){$("#modalTitle").textContent=title;$("#modalBody").innerHTML=body;$("#modal").classList.remove("hidden")}
function closeModal(){$("#modal").classList.add("hidden")}
function calc(c){return (c.entries||[]).reduce((a,e)=>({debt:a.debt+Number(e.debt||0),paid:a.paid+Number(e.paid||0)}),{debt:0,paid:0})}
function balance(c){let x=calc(c);return x.debt-x.paid}
function fmtDate(d){return d?new Date(d).toLocaleDateString("ar-YE"):new Date().toLocaleDateString("ar-YE")}
function render(){
  document.body.classList.toggle("dark",!!settings.dark);
  $("#drawerShopName").textContent=settings.shopName||"اسم المحل";
  $("#drawerShopPhone").textContent=settings.shopPhone||"";
  $("#drawerAvatar").innerHTML=settings.shopPhoto?`<img src="${settings.shopPhoto}">`:"🏪";
  if(currentPage==="home") renderHome();
  if(currentPage==="customer") renderCustomer();
  if(currentPage==="settings") renderSettings();
  if(currentPage==="about") renderAbout();
}
function renderHome(){
 $("#pageTitle").textContent="العملاء";
 $("#main").innerHTML=`<div class="page-head"><h2>حسابات العملاء</h2><span>${db.customers.length} عميل</span></div>
 ${db.customers.length?db.customers.map(c=>`<div class="card">
   <div class="customer">
    <div class="avatar">${c.photo?`<img src="${c.photo}">`:"👤"}</div>
    <div class="customer-main"><strong>${esc(c.name)}</strong><small>${esc(c.phone)} · SMS</small></div>
    <div class="balance ${balance(c)>0?"debt":"clear"}">${balance(c)>0?`متبقي ${money(balance(c))}`:"لا يوجد متبقي"}</div>
   </div>
   <div class="actions">
    <button class="primary" onclick="openCustomer('${c.id}')">فتح الحساب</button>
    <button class="outline" onclick="shareCustomer('${c.id}')">مشاركة</button>
    <button class="danger" onclick="deleteCustomer('${c.id}')">حذف</button>
   </div>
 </div>`).join(""):`<div class="empty"><div class="big">👥</div><h3>لا يوجد عملاء بعد</h3><p>اضغط + لإضافة أول عميل.</p></div>`}
 <button class="fab" onclick="addCustomer()">+</button>`;
}
function pickContact(){if(window.Android){Android.pickContact();}else toast("اختيار الأسماء متاح في نسخة Android الأصلية");}
function onContactSelected(name,phone){$("#cName").value=name||$("#cName").value;$("#cPhone").value=phone||"";}
function addCustomer(){
 modal("إضافة عميل",`<label>اسم العميل</label><input id="cName" placeholder="مثال: أحمد">
 <label>رقم العميل</label><div class="phone-pick"><input id="cPhone" inputmode="tel" readonly placeholder="اختر الرقم من سجل الأسماء"><button type="button" class="outline" onclick="pickContact()">اختيار من الأسماء</button></div>
  <label>صورة العميل (اختياري)</label><input id="cPhoto" type="file" accept="image/*">
 <label>وقت الرسالة التلقائية</label><input id="cSchedule" type="time" value="${settings.schedule}">
 <div class="actions"><button class="primary" onclick="saveCustomer()">حفظ العميل</button></div>`);
}
function saveCustomer(){
 const name=$("#cName").value.trim(), phone=$("#cPhone").value.trim();
 if(!name||!phone){toast("أدخل اسم العميل ورقمه");return}
 const file=$("#cPhoto").files[0], id=Date.now().toString();
 const finish=photo=>{const schedule=$("#cSchedule").value||settings.schedule;const c={id,name,phone,channel:"sms",schedule,photo:photo||"",entries:[]};db.customers.push(c);save();if(window.Android){Android.scheduleSms(String(id),phone,messageText(c),...schedule.split(":").map(Number));}closeModal();render();toast("تم حفظ العميل")};
 if(file){const r=new FileReader();r.onload=()=>finish(r.result);r.readAsDataURL(file)}else finish("");
}
function openCustomer(id){currentCustomer=db.customers.find(x=>x.id===id);currentPage="customer";closeDrawer();render()}
function renderCustomer(){
 const c=currentCustomer;if(!c){currentPage="home";return render()}
 $("#pageTitle").textContent=c.name;
 const s=calc(c), bal=s.debt-s.paid;
 $("#main").innerHTML=`<div class="page-head"><button class="outline" onclick="goHome()">← العملاء</button><div><strong>${esc(c.name)}</strong><br><small>${esc(c.phone)}</small></div></div>
 <div class="stats"><div class="stat">إجمالي الدين<b>${money(s.debt)}</b></div><div class="stat">المسدد<b>${money(s.paid)}</b></div><div class="stat">متبقي عليه<b>${money(bal)}</b></div></div>
 <div class="actions"><button class="primary" onclick="shareCustomer('${c.id}')">مشاركة Android</button><button class="secondary" onclick="sendMessage('${c.id}')">إرسال رسالة</button><button class="outline" onclick="printCustomer('${c.id}')">حفظ PDF</button><button class="outline" onclick="editCustomer('${c.id}')">تعديل</button></div>
 <div class="section-title">السجل</div>
 ${c.entries.length?c.entries.slice().reverse().map((e,i)=>`<div class="card">
  <div class="debt-row">
   <div><span class="row-head">اليوم</span><b>${esc(e.day)}</b></div>
   <div><span class="row-head">التاريخ</span><b>${esc(e.date)}</b></div>
   <div><span class="row-head">التفاصيل</span><b>${esc(e.details)}</b></div>
   <div><span class="row-head">لدين</span><b>${money(e.debt)}</b></div>
   <div><span class="row-head">مسدد</span><b>${money(e.paid)}</b></div>
   <div><span class="row-head">متبقي</span><b>${money(Number(e.debt||0)-Number(e.paid||0))}</b></div>
   <div><span class="row-head">ملاحظة</span><b>${esc(e.note||"-")}</b></div>
  </div>
  <div class="actions"><button class="small-btn" onclick="editEntry('${c.id}','${e.id}')">تعديل</button><button class="small-btn" onclick="deleteEntry('${c.id}','${e.id}')">حذف</button></div>
 </div>`).join(""):`<div class="empty"><div class="big">🧾</div><p>لا توجد عمليات لهذا العميل.</p></div>`}
 <button class="fab" onclick="addEntry('${c.id}')">+</button>`;
}
function addEntry(cid){
 modal("إضافة حركة",`<div class="grid2"><div><label>اليوم</label><input id="eDay" value="${new Date().toLocaleDateString('ar-YE',{weekday:'long'})}"></div>
 <div><label>التاريخ</label><input id="eDate" type="date" value="${new Date().toISOString().slice(0,10)}"></div></div>
 <label>التفاصيل</label><input id="eDetails" placeholder="مثال: مشتريات">
 <div class="grid2"><div><label>لدين</label><input id="eDebt" type="number" inputmode="decimal" value="0"></div><div><label>مسدد</label><input id="ePaid" type="number" inputmode="decimal" value="0"></div></div>
 <label>ملاحظة</label><textarea id="eNote" rows="3"></textarea>
 <div class="actions"><button class="primary" onclick="saveEntry('${cid}')">حفظ</button></div>`);
}
function saveEntry(cid,id=null){
 const c=db.customers.find(x=>x.id===cid);
 const data={id:id||Date.now().toString(),day:$("#eDay").value,date:$("#eDate").value,details:$("#eDetails").value,debt:Number($("#eDebt").value||0),paid:Number($("#ePaid").value||0),note:$("#eNote").value};
 if(id){const i=c.entries.findIndex(x=>x.id===id);c.entries[i]=data}else c.entries.push(data);
 save();closeModal();currentCustomer=c;renderCustomer();
}
function editEntry(cid,id){const c=db.customers.find(x=>x.id===cid),e=c.entries.find(x=>x.id===id);modal("تعديل الحركة",`<div class="grid2"><div><label>اليوم</label><input id="eDay" value="${esc(e.day)}"></div><div><label>التاريخ</label><input id="eDate" type="date" value="${esc(e.date)}"></div></div><label>التفاصيل</label><input id="eDetails" value="${esc(e.details)}"><div class="grid2"><div><label>لدين</label><input id="eDebt" type="number" value="${e.debt}"></div><div><label>مسدد</label><input id="ePaid" type="number" value="${e.paid}"></div></div><label>ملاحظة</label><textarea id="eNote" rows="3">${esc(e.note)}</textarea><div class="actions"><button class="primary" onclick="saveEntry('${cid}','${id}')">حفظ التعديل</button></div>`)}
function deleteEntry(cid,id){if(confirm("حذف هذه الحركة؟")){const c=db.customers.find(x=>x.id===cid);c.entries=c.entries.filter(x=>x.id!==id);save();currentCustomer=c;renderCustomer()}}
function editCustomer(id){
 const c=db.customers.find(x=>x.id===id);modal("تعديل بيانات العميل",`<label>اسم العميل</label><input id="cName" value="${esc(c.name)}"><label>رقم العميل</label><div class="phone-pick"><input id="cPhone" value="${esc(c.phone)}" readonly><button type="button" class="outline" onclick="pickContact()">اختيار من الأسماء</button></div><label>تغيير الصورة</label><input id="cPhoto" type="file" accept="image/*">
 <label>وقت الرسالة التلقائية</label><input id="cSchedule" type="time" value="${esc(c.schedule||settings.schedule)}"><div class="actions"><button class="primary" onclick="updateCustomer('${id}')">حفظ</button></div>`)
}
function updateCustomer(id){
 const c=db.customers.find(x=>x.id===id);c.name=$("#cName").value.trim();c.phone=$("#cPhone").value.trim();c.channel="sms";c.schedule=$("#cSchedule").value||settings.schedule;
 const f=$("#cPhoto").files[0],done=photo=>{if(photo)c.photo=photo;save();if(window.Android)Android.scheduleSms(String(id),c.phone,messageText(c),...c.schedule.split(":").map(Number));closeModal();currentCustomer=c;renderCustomer()};if(f){const r=new FileReader();r.onload=()=>done(r.result);r.readAsDataURL(f)}else done("");
}
function deleteCustomer(id){if(confirm("سيتم حذف العميل وكل سجله. هل أنت متأكد؟")){if(window.Android)Android.cancelSms(String(id));db.customers=db.customers.filter(x=>x.id!==id);save();render()}}
function goHome(){currentPage="home";currentCustomer=null;render()}
function messageText(c){const bal=balance(c);return `مرحباً ${c.name}، معكم ${settings.shopName||"إدارة المحل"}.\n\nمتبقي عليكم مبلغ وقدره: ${money(bal)}\n\nشكراً لكم.`}
function normalizePhone(p){return p.replace(/[^0-9+]/g,"")}
function sendMessage(id){
 const c=db.customers.find(x=>x.id===id), text=messageText(c), phone=normalizePhone(c.phone);
 if(window.Android){Android.sendSms(phone,text);}else location.href=`sms:${phone}?body=${encodeURIComponent(text)}`;
}
async function shareCustomer(id){
 const c=db.customers.find(x=>x.id===id), s=calc(c);
 const text=`حساب العميل: ${c.name}\nإجمالي الدين: ${money(s.debt)}\nالمسدد: ${money(s.paid)}\nالمتبقي: ${money(s.debt-s.paid)}\n${messageText(c)}`;
 if(navigator.share){try{await navigator.share({title:`حساب ${c.name}`,text})}catch(e){}}
 else {await navigator.clipboard?.writeText(text);toast("تم نسخ البيانات للمشاركة")}
}
function printCustomer(id){
 const c=db.customers.find(x=>x.id===id),s=calc(c);
 const rows=c.entries.map(e=>`<tr><td>${esc(e.day)}</td><td>${esc(e.date)}</td><td>${esc(e.details)}</td><td>${money(e.debt)}</td><td>${money(e.paid)}</td><td>${money(Number(e.debt||0)-Number(e.paid||0))}</td><td>${esc(e.note||'')}</td></tr>`).join('');
 const w=window.open('','_blank');
 if(!w){toast('اسمح بفتح النوافذ المنبثقة لحفظ PDF');return}
 w.document.write(`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>حساب ${esc(c.name)}</title><style>body{font-family:Arial;padding:20px;color:#123c3a}h1{color:#0d6b57}table{width:100%;border-collapse:collapse}th,td{border:1px solid #bbb;padding:7px;text-align:right;font-size:12px}th{background:#dff5fb}.sum{margin-top:15px;font-weight:bold}</style></head><body><h1>${esc(settings.shopName||'حسابات العملاء')}</h1><h2>حساب العميل: ${esc(c.name)}</h2><p>الرقم: ${esc(c.phone)}</p><table><tr><th>اليوم</th><th>التاريخ</th><th>التفاصيل</th><th>لدين</th><th>مسدد</th><th>متبقي</th><th>ملاحظة</th></tr>${rows}</table><div class="sum">إجمالي الدين: ${money(s.debt)} — المسدد: ${money(s.paid)} — المتبقي: ${money(s.debt-s.paid)}</div><script>window.onload=()=>setTimeout(()=>window.print(),250)<\/script></body></html>`);
 w.document.close();
 toast('اختر «حفظ كملف PDF» من شاشة الطباعة');
}
function renderSettings(){
 $("#pageTitle").textContent="الإعدادات";
 $("#main").innerHTML=`<div class="card"><div class="section-title">بيانات صاحب المحل</div>
 <label>اسم صاحب المحل / البقالة</label><input id="shopName" value="${esc(settings.shopName)}" placeholder="مثال: محمد الجدمي">
 <label>رقم صاحب المحل</label><input id="shopPhone" value="${esc(settings.shopPhone)}" inputmode="tel">
 <label>صورة صاحب المحل</label><input id="shopPhoto" type="file" accept="image/*">
 <div class="actions"><button class="primary" onclick="saveSettings()">حفظ البيانات</button></div></div>
 <div class="card"><div class="inline"><div><b>قفل الشاشة</b><br><small>يمكن تفعيله أو إيقافه</small></div><label class="switch"><input id="lockToggle" type="checkbox" ${settings.lock?"checked":""} onchange="toggleLock(this.checked)"><span class="slider"></span></label></div>
 ${settings.lock?`<label>رمز القفل</label><input id="pinSet" type="password" inputmode="numeric" maxlength="6" value="${esc(settings.pin)}"><button class="outline" style="margin-top:8px" onclick="setPin()">حفظ رمز القفل</button>`:""}
 </div>
 <div class="card"><div class="inline"><b>الوضع الليلي</b><label class="switch"><input id="darkToggle" type="checkbox" ${settings.dark?"checked":""} onchange="settings.dark=this.checked;save();render()"><span class="slider"></span></label></div>
 <div class="info">الرسائل عبر SMS فقط — لا يوجد واتساب في هذه النسخة.</div>
 <label>وقت التذكير / الإرسال المقرر</label><input type="time" value="${settings.schedule}" onchange="settings.schedule=this.value;save()">
 <div class="notice">سيتم تجهيز الرسالة تلقائياً بالاسم والمبلغ المتبقي. الإرسال التلقائي SMS يتم بواسطة مكوّن Android الأصلي حتى عند إغلاق التطبيق.</div>
 </div>`;
}
function saveSettings(){
 settings.shopName=$("#shopName").value.trim();settings.shopPhone=$("#shopPhone").value.trim();
 const f=$("#shopPhoto").files[0],done=photo=>{if(photo)settings.shopPhoto=photo;save();render();toast("تم حفظ الإعدادات")};if(f){const r=new FileReader();r.onload=()=>done(r.result);r.readAsDataURL(f)}else done("");
}
function toggleLock(v){settings.lock=v;if(v&&!settings.pin){settings.pin=prompt("ضع رمز قفل رقمي")||""}save();render()}
function setPin(){settings.pin=$("#pinSet").value.trim();save();toast("تم حفظ رمز القفل")}
function renderAbout(){
 $("#pageTitle").textContent="نبذة عن التطبيق";
 $("#main").innerHTML=`<div class="card"><h2>حسابات العملاء</h2><p>تطبيق لإدارة حسابات العملاء والديون، إضافة الحركات، حساب المتبقي، المشاركة عبر Android Sharesheet، وتجهيز كشف PDF.</p><hr><p><b>المطور:</b> مؤسسة يد الخير للمقاولات العامة</p><p><b>الهاتف:</b> 00 967774737017</p><p>الإصدار المستهدف: Android 5 وما فوق.</p></div>
 <div class="card"><b>ملاحظة مهمة</b><p>الحفظ داخل التطبيق محلي على الجهاز. النسخة الاحتياطية تُصدّر ملف JSON يمكن الاحتفاظ به أو مشاركته، بينما رفع الملف إلى Google Drive يحتاج تسجيل دخول المستخدم في Drive.</p></div>`;
}
function backup(){
 const blob=new Blob([JSON.stringify({db,settings},null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="حسابات_العملاء_نسخة_احتياطية.json";a.click();URL.revokeObjectURL(a.href);toast("تم إنشاء النسخة الاحتياطية")}
async function drive(){
 const data=JSON.stringify({db,settings},null,2);
 const blob=new Blob([data],{type:'application/json'});
 const file=new File([blob],'حسابات_العملاء_نسخة_احتياطية.json',{type:'application/json'});
 if(navigator.share && navigator.canShare && navigator.canShare({files:[file]})){
  try{await navigator.share({title:'نسخة احتياطية حسابات العملاء',text:'بيانات التطبيق',files:[file]});return}catch(e){}
 }
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=file.name;a.click();toast('تم إنشاء ملف النسخة الاحتياطية. ارفعه إلى Google Drive');
}
$("#menuBtn").onclick=openDrawer;$("#drawerShade").onclick=closeDrawer;$("#closeModal").onclick=closeModal;$("#themeBtn").onclick=()=>{settings.dark=!settings.dark;save();render()};
document.querySelectorAll(".drawer [data-page]").forEach(b=>b.onclick=()=>{currentPage=b.dataset.page;closeDrawer();render()});
$("#backupBtn").onclick=backup;$("#driveBtn").onclick=drive;
window.addEventListener("load",()=>{
 setTimeout(()=>{$("#splash").classList.add("hidden"); if(settings.lock&&settings.pin){$("#lockScreen").classList.remove("hidden")}else{$("#app").classList.remove("hidden");render()}},2000);
});
$("#unlockBtn").onclick=()=>{if($("#pinInput").value===settings.pin){$("#lockScreen").classList.add("hidden");$("#app").classList.remove("hidden");render()}else toast("رمز القفل غير صحيح")};
let lastScheduleMinute='';
setInterval(()=>{
 if(!settings.shopName || document.hidden)return;
 const now=new Date(),hm=String(now.getHours()).padStart(2,'0')+':'+String(now.getMinutes()).padStart(2,'0');
 const stamp=now.toISOString().slice(0,10)+' '+hm;
 if(stamp===lastScheduleMinute)return;
 lastScheduleMinute=stamp;
 db.customers.filter(c=>(c.schedule||settings.schedule)===hm).forEach(c=>{if(window.Android){Android.scheduleSms(String(c.id),c.phone,messageText(c),...((c.schedule||settings.schedule).split(":").map(Number)));}else{toast('يلزم إصدار Android الأصلي للإرسال التلقائي');}});
},1000);
